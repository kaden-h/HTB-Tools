from twister import Twister
import galois
import numpy as np
import socket
import time
import sys
import pickle
import os

ip = "127.0.0.1"
port = 31337

SAVE_FILE = "observations.pkl"

def recv_all(s):
    s.settimeout(0.05)
    data = b''
    try:
        while True:
            chunk = s.recv(1024)
            if not chunk:
                break
            data += chunk
    except socket.timeout:
        pass
    s.settimeout(None)
    return data

def bet(s, option, amount, debug=False, guess=0):
    s.sendall(str(option).encode() + b'\n')
    data = recv_all(s)
    if debug:
        print("Option: {}".format(option))
        print(data)
    if option == 3:
        s.sendall(str(guess).encode() + b'\n')
        data = recv_all(s)
        if debug:
            print("Guess: {}".format(guess))
            print(data)
    s.sendall(str(amount).encode() + b'\n')
    data = recv_all(s)
    if debug:
        print("Bet: {}".format(amount))
        print(data)
    text = data.decode('utf-8')
    result = int(text.split("stops at ")[1].split("\n")[0])
    coins = int(text.split("You have ")[1].split(" ")[0])
    if debug:
        print("Result: {}\nCoins: {}".format(result, coins))
    return result, coins

def save_observations(data):
    with open(SAVE_FILE, 'wb') as f:
        pickle.dump(data, f)
    print(f"Saved observations to {SAVE_FILE}")

def load_observations():
    with open(SAVE_FILE, 'rb') as f:
        data = pickle.load(f)
    print(f"Loaded observations from {SAVE_FILE}")
    return data

def collect_observations():
    """Connect to server, double bet to build bankroll, then collect 8 twists of observations."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        data = recv_all(s)
        print(data.decode('utf-8'))

        money = 50
        all_results = []   # list of lists: each inner list is 128 results (one twist)

        # --- Bankroll phase: double up twice to get enough buffer ---
        print("Gambling to build bankroll...")
        result, money = bet(s, 1, 49)
        if money < 50:
            print("Lost 50% bet, exiting.")
            return None
        print(f"Won first bet, money={money}")

        result, money = bet(s, 1, 98)
        if money < 50:
            print("Lost 25% bet, exiting.")
            return None
        print(f"Won second bet, money={money}")

        # Those two bets consumed 2 rand() calls, not full twists.
        # Record them so we can account for them in the matrix build.
        # We need to track ALL outputs from the very first rand() call.
        # So record the first two results too.
        bankroll_results = [result]  # second bet result (first was consumed above)
        # Re-fetch first result - it was consumed by bet() internally, grab from call above
        # Actually both are already consumed - we need to record both
        # Let's redo this cleanly:

        # Restart: reconnect and record everything from the start
        print("Reconnecting to record all outputs from the beginning...")

    # Reconnect fresh
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        data = recv_all(s)
        print(data.decode('utf-8'))

        money = 50
        all_results = []
        twist_results = []

        gambling = 49

        # Collect full twists worth of data, 128 results per twist
        # We need at least 8 twists (1024 results) to saturate rank
        # But we also need to handle the bankroll phase carefully:
        # Every bet consumes exactly one rand() call regardless of option.
        # So we just record every single result in order.

        target_twists = 8  # 8 * 128 = 1024 observations, more than enough

        for twist_num in range(target_twists):
            print(f"Collecting twist {twist_num}...")
            twist_results = []
            for i in range(128):
                result, money = bet(s, 1, gambling)

                # Bankroll logic: first two bets are gambles
                if gambling == 49:
                    if money < 50:
                        print("Lost 50% bet :(")
                        return None
                    gambling = 98
                elif gambling == 98:
                    if money < 50:
                        print("Lost 25% bet :(")
                        return None
                    gambling = 1

                twist_results.append(result)

            all_results.append(twist_results)
            print(f"Twist {twist_num} done. Money={money}, first 5: {twist_results[:5]}")

        obs_data = {
            'all_results': all_results,
            'money': money,
        }
        save_observations(obs_data)
        return obs_data

def build_twist_matrix():
    T = np.eye(4096, dtype=np.int_)
    c = np.zeros(4096, dtype=np.int_)
    magic_bits = [1,0,1,1,0,0,1,0,0,1,0,0,1,0,0,1,1,0,1,1,0,0,0,0,0,0,0,1,0,1,0,1]
    # [1,0,1,1,0,0,1,0,0,1,0,0,1,0,0,1,1,0,1,1,0,0,0,0,0,0,0,1,0,1,0,1]
    for i in range(128):
        neighbour = (i + 1) % 128
        for bit in range(32):
            src_bit = (bit + 3) % 32
            T[i*32 + bit] ^= T[neighbour*32 + src_bit]
            T[i*32 + bit] %= 2
            c[i*32 + bit] ^= c[neighbour*32 + src_bit]
            c[i*32 + bit] %= 2
        neighbour_m = (i + 30) % 128
        for bit in range(32):
            src_bit = (bit + 23) % 32
            T[i*32 + bit] ^= T[neighbour_m*32 + src_bit]
            T[i*32 + bit] %= 2
            c[i*32 + bit] ^= c[neighbour_m*32 + src_bit]
            c[i*32 + bit] %= 2
        for bit in range(32):
            c[i*32 + bit] ^= magic_bits[bit]
            c[i*32 + bit] %= 2
    return T, c

def build_tempering_matrix():
    # y ^= rol(y, 7)  -- in-place, so read from evolving state
    M = np.eye(4096, dtype=np.int_)
    for iteration in range(128):
        for bit in range(32):
            newbit = (bit + 7) % 32
            M[iteration * 32 + bit][iteration * 32 + newbit] ^= 1

    M_g = galois.GF2(M.copy())
    # y ^= rol(y, 17) -- in-place on already-modified y
    for iteration in range(128):
        for bit in range(32):
            newbit = (bit + 17) % 32
            M_g[iteration * 32 + bit] ^= M_g[iteration * 32 + newbit]

    return M_g

def bits_to_state(bits):
    state = []
    for i in range(128):
        word = 0
        for bit in range(32):
            word |= (int(bits[i*32 + bit]) << (31 - bit))
        state.append(word)
    return state

def solve(obs_data):
    all_results = obs_data['all_results']
    money = obs_data['money']

    print("Building tempering matrix M_g...")
    M_g = build_tempering_matrix()
    print(f"Rank of M_g: {np.linalg.matrix_rank(M_g)}")

    print("Building twist matrix T...")
    T, c = build_twist_matrix()
    T_g = galois.GF2(T)
    c_g = galois.GF2(c)

    # Build constraint matrix from observations
    # For twist k: observed_bits = M_g[rows 27-31 per word] @ T^k @ state_0 + affine
    C_matrix = np.zeros((0, 4096), dtype=np.int_)
    C_soln   = np.zeros((0, 1),    dtype=np.int_)

    T_power  = galois.GF2(np.eye(4096, dtype=np.int_))
    accum_c  = galois.GF2(np.zeros(4096, dtype=np.int_))

    for loop, twist_results in enumerate(all_results):
        # Convert results to bits
        C_array_bits = []
        for n in twist_results:
            C_array_bits.append([(n >> i) & 1 for i in range(4, -1, -1)])

        for i, j in enumerate(C_array_bits):
            for k, l in enumerate(j):
                if loop == 0:
                    coeff_row = np.array(M_g[i*32 + 27 + k]).reshape(1, 4096)
                    rhs = l
                else:
                    coeff_row = np.array(M_g[i*32 + 27 + k] @ T_power).reshape(1, 4096)
                    rhs = (l ^ int(galois.GF2(np.array(M_g[i*32 + 27 + k])) @ accum_c)) % 2
                C_matrix = np.vstack([C_matrix, coeff_row])
                C_soln   = np.vstack([C_soln, np.array([[rhs]])])

        rank = np.linalg.matrix_rank(galois.GF2(C_matrix))
        print(f"After twist {loop}: C_matrix shape={C_matrix.shape}, rank={rank}")
        if rank >= 3968:
            print("Sufficient rank reached, stopping early.")
            break

        accum_c = T_g @ accum_c ^ c_g
        T_power = T_g @ T_power

    # How many twists did we actually use?
    twists_used = loop + 1
    print(f"Twists used: {twists_used}")

    print("Running RREF...")
    augmented = galois.GF2(np.hstack([C_matrix.astype(int), C_soln.astype(int)]))
    rref = augmented.row_reduce()

    # Extract particular solution
    particular = np.zeros(4096, dtype=np.int_)
    for row_idx in range(rref.shape[0]):
        row = np.array(rref[row_idx])
        pivot_candidates = np.where(row[:4096] == 1)[0]
        if len(pivot_candidates) == 0:
            continue
        particular[pivot_candidates[0]] = int(row[4096])

    print(f"Particular solution nonzero bits: {np.sum(particular)}")

    candidate_state = bits_to_state(particular)
    print(f"Candidate state (first 5): {candidate_state[:5]}")

    return candidate_state, twists_used, money

def win(candidate_state, twists_used, money):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        data = recv_all(s)
        print(data.decode('utf-8'))

        # This is a FRESH connection - the server creates a new Twister.
        # We cannot reuse a solved state across connections.
        # The solve and win must happen in the same connection.
        print("ERROR: win() must be called within the same connection as collect().")
        print("Restructure to solve+win in one session.")

# ── Main ────────────────────────────────────────────────────────────────────

if os.path.exists(SAVE_FILE):
    print(f"Found {SAVE_FILE}, loading cached observations.")
    obs_data = load_observations()
else:
    print("No cache found, collecting observations from server.")
    obs_data = collect_observations()
    if obs_data is None:
        print("Collection failed.")
        sys.exit(1)

candidate_state, twists_used, money = solve(obs_data)

# ── Same-connection win phase ────────────────────────────────────────────────
# NOTE: The above solve() works offline on cached data.
# For the actual win, we need to solve AND bet in the same TCP connection.
# Run this block instead when you're ready to go live:

print("\n--- To go live, run the combined collect+solve+win below ---")
print("Delete observations.pkl first to force a fresh run.")