import socketserver
import signal
from twister import Twister
def handle(self):
    signal.alarm(500)
    self.write("Welcome to the Casino")
    self.write("We are playing roulette today")
    money = 50
    random = Twister()
    self.write("The wheel stops on a number between 0 and 31.")
    self.write("\n")
    while money > 0:
        self.write("You have {} coins".format(money))
        self.write("What would you like to bet on:")
        self.write("1) Even")
        self.write("2) Odd")
        self.write("3) Number")
        option = int(self.query("Option: ").strip())
        if option < 1 or option > 3:
            self.write("Invalid Option.")
            self.close()
            return
        if option == 3:
            guess = int(self.query("Pick a number: ").strip())
        bet = int(self.query("Bet: ").strip())
        if bet <= 0 or bet > money:
            self.write("Invalid Bet.")
            self.close()
            return
        number = random.rand() % 32
        self.write("The wheel stops at {}".format(number))
        if option == 1:
            if number % 2 == 0:
                money += bet
            else:
                money -= bet
        elif option == 2:
            if number % 2 == 1:
                money += bet
            else:
                money -= bet
        elif option == 3:
            if number == guess:
                money += bet * 10
            else:
                money -= bet * 10
        if money >= 10000000000000:
            self.write("Congrats, you beat the house.")
            self.write("Here's your reward: {}".format(open("flag.txt", "rb").read()))
            self.close()
            return
    self.write("You ran out of money. Better luck next time.")
    self.close()
class RequestHandler(socketserver.BaseRequestHandler):
    handle = handle
    def read(self, until=b'\n'):             # FIX 1: use bytes delimiter
        out = b''                             # FIX 2: accumulate as bytes
        while not out.endswith(until):
            out += self.request.recv(1)
        return out[:-len(until)].decode()     # FIX 3: strip delimiter, decode to str
    def query(self, string=''):
        self.write(string, newline=False)
        return self.read()
    def write(self, string, newline=True):
        if isinstance(string, str):
            string = string.encode()
        self.request.sendall(string)
        if newline:
            self.request.sendall(b'\n')
    def close(self):
        self.request.close()
class Server(socketserver.ForkingTCPServer):
    allow_reuse_address = True
    def handle_error(self, request, client_address):
        request.close()                       # FIX 4: was self.request, should be request
port = 31337
server = Server(('0.0.0.0', port), RequestHandler)
server.serve_forever()