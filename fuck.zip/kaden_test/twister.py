import os
import random

N = 128
M = 30
b = 32
MAGIC = 0xb249b015
mask = (1 << b) - 1 # 0b111111...111 x32

class Twister:
	def rol(self, x, d):
		ans = (x << d) & mask # The & mask here just makes it 32 bit.
							  # First, left-shift d bits
		ans = ans | (x >> (b - d)) # Then, standard "OR" operator, rightshift 32 minus d bits
		return ans & mask # The & mask here just makes it 32 bit
		# Essentially, it left shifts it D amount, but it keeps the value of those bits by right shifting the same amount and ORing them
		# Here's an example:
		# 0b10010010 rol 3
		# First:
		# 0b10010010000 mod 8 = 0b10010000
		# Second:
		# 0b10010000 OR 0b00000100 = 
		# 0b10010100
		# The 100 from the left was wrapped around to the right. But this is 32 bit

	def __init__(self, state=None):
		self.index = N # self.index = 128
		if state is not None:
			assert len(state) == N # we can set the state of the randomizer by calling it. Could be important to solving
			self.STATE = state[:]
		else:
			self.STATE = [0] * N # [0 0 0 0 ... 0 ] x128
			for i in range(N):
				self.STATE[i] = int.from_bytes(os.urandom(4), 'big') # [random 32 bit values]
			for i in range(N):
				self.STATE[i] ^= random.getrandbits(32) # Bitwise XOR
		# Debug Overwrite: self.STATE
		# This guarantees first 2 are even after a twist
		self.STATE = [3211989997, 2949026168, 1304322548, 785927585, 3316371532, 3975232194, 4180406701, 1296050202, 2368981480, 2588794230, 452335559, 1439951632, 2081338854, 3923429165, 19588768, 680869649, 1033714093, 3400566183, 2099511821, 1021287360, 3157975665, 3939357336, 2297331084, 3190303181, 1673167803, 3320649257, 3422597296, 874820375, 3068202593, 3660975166, 1516640187, 2943925012, 800822320, 1803342325, 1297964829, 1708884782, 2229162201, 3509915494, 2175102977, 1015224493, 3363932939, 2299888663, 1621754902, 3987660318, 2506247503, 3323532028, 1263431675, 1860599513, 1075741498, 1488803317, 2033699349, 1756705932, 1967175459, 4215057834, 1430720831, 1275123033, 1229299936, 2580458542, 1318705295, 3872630652, 506778024, 2103887746, 823978341, 1373772299, 1860941464, 499016862, 3355815898, 1877345803, 3108016387, 2494687474, 1599278351, 3151747436, 866099853, 3762461834, 3374270414, 3124983715, 3230535916, 328970746, 3395057434, 3339115400, 3621047941, 3117649453, 1518112521, 2579547529, 1626752887, 2818517401, 1960568203, 1836366776, 1732448533, 199124079, 208588578, 4219436203, 2612176655, 2619224682, 4009533864, 1440515799, 3681715026, 286351984, 1113206765, 3992570269, 2019953014, 1256043675, 1511496285, 3010748807, 1642635718, 888201353, 3534524835, 380094930, 1211581720, 1239119863, 2699147540, 2016056978, 646472965, 2955303870, 1606791863, 343356472, 4014713338, 3070718148, 3201624888, 4186367589, 3809159529, 3761956343, 1775996294, 737130030, 3632290637, 2514073291, 1649398728, 2565499789]
		print(f"DEBUG: Self.STATE: {self.STATE}")
			# Note - random.getrandbits() uses the Mersenne Twister PRNG, which is NOT cryptographically secure... 
			# and the class name is twister. However, os.urandom() IS cryptographically secure, so for all 
			# intents and purposes, N is self.STATE is random for the initial state

	def twist(self):
		for i in range(N):
			self.STATE[i] ^= self.rol(self.STATE[(i+1) % N], 3) # state[i] = state[i] XOR rol(state[i+1] % 128, 3)
			self.STATE[i] ^= self.rol(self.STATE[(i+M) % N], b - 9) # state[i] = state[i] XOR rol(state[i - 2] % 128, 23)
			self.STATE[i] ^= MAGIC # state[i] = state[i] XOR 0xb249b015

	def rand(self):
		if self.index >= N: # the first calling of rand() by number = random.rand() % 32 in the other script
							# triggers this, because self.index was set to 128 in the initializer
			self.twist()
			print(f"DEBUG: Self.STATE: {self.STATE}")
			self.index = 0
		y = self.STATE[self.index] # y = state[index]
		y ^= self.rol(y, 7) # y = y XOR rol(y, 7)
		y ^= self.rol(y, b - 15) # y = y XOR rol(y, 17)
		self.index += 1 # Move on to next index

		return y & mask # return 32 bits of y, in theory &mask shouldn't matter here. Probably just a safety thing
						# The lower 5 bits of this are what we see in the roulette function.

	###
	# GOAL: Determine the entirety of self.STATE, 5 bits at a time, from a few thousand requests
	### 
	# PSEUDOCODE
	#
	# a = STATE[index]
	# index++
	# b = a XOR rol(a, 7)
	# c = b XOR rol(b, 17)
	# return c
